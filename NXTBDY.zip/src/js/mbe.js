define(['jquery', 'mcs'], function ($, mcs) {
  //define MCS mobile backend connection details
  var mcs_config = {
    "logLevel": mcs.logLevelVerbose,
    "mobileBackends": {
      "NXTBDY": {
        "default": true,
        "baseUrl": "https://mobile-apacdemo08.mobileenv.us2.oraclecloud.com:443",
        "applicationKey": "b52d16c0-815d-4f67-8f09-bcd19ef50939",
        "authorization": {
          "basicAuth": {
            "backendId": "b52d16c0-815d-4f67-8f09-bcd19ef50939",
            "anonymousToken": "QVBBQ0RFTU8wOF9NT0JJTEVfTU9CSUxFX0FOT05ZTU9VU19BUFBJRDpLcDNxaWRydG81LmZ6bA=="
          },
          "oAuth": {
            "clientId": "7eaa1228-ae52-49ae-b20d-865f7630ab28",
            "clientSecret": "WHGvOXXArycBzjREZub6",
            "tokenEndpoint": "https://apacdemo08.identity.us.oraclecloud.com/oam/oauth2/tokens"
          },
          "facebookAuth":{  
            "facebookAppId": "755531654651395",  
            "backendId": "b52d16c0-815d-4f67-8f09-bcd19ef50939",
            "anonymousToken": "QVBBQ0RFTU8wOF9NT0JJTEVfTU9CSUxFX0FOT05ZTU9VU19BUFBJRDpLcDNxaWRydG81LmZ6bA=="
         }  
        }
      }
    }
  };
 
  function MobileBackend() {
    var self = this;
    self.mobileBackend;
    function init() {
      mcs.MobileBackendManager.platform = new mcs.BrowserPlatform();
      mcs.MobileBackendManager.setConfig(mcs_config);
      //MCS backend name for example is JETSample. 
      self.mobileBackend = mcs.MobileBackendManager.getMobileBackend('NXTBDY');
      self.mobileBackend.setAuthenticationType("basicAuth");            
    }

    //Handles the success and failure callbacks defined here
    //Not using anonymous login for this example but including here. 
    self.authAnonymous = function () {
      console.log("Authenticating anonymously");
      var deferred = $.Deferred();
      self.mobileBackend.Authorization.authenticateAnonymous(
        function (response, data) {                        
          console.log("Success authenticating against mobile backend");
          deferred.resolve();
        },
        function (statusCode, data) {
          console.log("Failure authenticating against mobile backend");
          deferred.reject();
        }
      );
      return deferred.promise();
    };

    self.mcsSync = function (method, model, options) {

      var httpUrl, httpVerb, httpPayload = null;
      switch (method) {
        case "read":
          httpUrl = (model instanceof oj.Model) ? model.url + "/" + model.id : model.url;
          httpVerb = "GET";
          httpPayload = null;
          break;
        case "create":
          // httpUrl - adding id to URL depends on what's supported by the service
          httpVerb = "POST";
          httpPayload = model.toJSON();
          break;
        case "patch":
        case "update":
        case "delete":
          httpUrl = (model instanceof oj.Model) ? httpUrl + "/" + model.id : httpUrl;
          if (method == "patch")       httpVerb = "PATCH";
          else if (method == "update") httpVerb = "PUT";
          else if (method == "delete") httpVerb = "DELETE";
          if (method != "delete")
            httpPayload = model.toJSON();
          break;
      }
      console.log("Executing ", httpUrl, httpVerb, httpPayload);

      self.invokeCustomAPI(httpUrl, httpVerb, httpPayload).then(function(data) {
        options.success(data, null, options);
      }, function(statusCode, data) {
        options.error(data, null, options);
      });

      return [];
    };

    self.getCurrentUser = function() {
      var deferred = $.Deferred();
      self.mobileBackend.Authorization.getCurrentUser(function(statusCode, data) {
        deferred.resolve(data);
      }, function(statusCode, data) { 
        deferred.reject(statusCode, data);
      });
      return deferred.promise();
    };

    self.invokeCustomAPI = function(uri,method,payload) {
      var deferred = $.Deferred();
      self.mobileBackend.CustomCode.invokeCustomCodeJSONRequest(uri , method , payload, function(statusCode,data) {
        deferred.resolve(data);
      }, function(statusCode,data) {
        deferred.reject(statusCode, data);
      });
      return deferred.promise();
    };

    //This handles success and failure callbacks using parameters (unlike the authAnonymous example)
    self.authenticate = function (username, password, successCallback, failureCallback) {
      self.mobileBackend.Authorization.authenticate(username, password, successCallback, failureCallback);
    };

    //this handles success and failure callbacks using parameters
    self.logout = function (successCallback, failureCallback) {
      self.mobileBackend.Authorization.logout();
    };

    self.isAuthorized = function () {
      return self.mobileBackend.Authorization.isAuthorized;
    };
    
    init();
  }
 
  return new MobileBackend();
});